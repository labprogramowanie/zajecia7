﻿using BibliotekaKlas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotekaKlas
{
    class Lista
    {
        List<Pracownik> lista;
        public Lista(List<Pracownik> l)
        {
            lista = l;
        }

        public void Dodaj(Pracownik pracownik)
        {
            lista.Add(pracownik);
        }
        public void WstawWPolozenie(int indeks, Pracownik pracownik)
        {
            lista.Insert(indeks, pracownik);
        }
        public int Usun(string nazwisko)
        {
            foreach (Pracownik p in lista)
            {
                if (p.Nazwisko == nazwisko)
                {
                    int i = lista.IndexOf(p);
                    lista.Remove(p);
                    return i;
                }
            }
            return -1;
        }
        public void Usun(int indeks)
        {
            if (indeks >= 0)
            {
                lista.RemoveAt(indeks);
            }


            else { Console.WriteLine("Zly index"); }

        }
        public Pracownik szukaj(string nazwisko)
        {
            foreach (Pracownik p in lista)
            {
                if (p.Nazwisko == nazwisko)
                {
                    return p;
                }

            }
            return null;

        }

        public class sortowanie
        {

            public class PoNazwisku : IComparer<Pracownik>
            {
                public int Compare(Pracownik x, Pracownik y)
                {
                    return x.Nazwisko.CompareTo(x.Nazwisko);
                }
            }
            public class PoZawodzie : IComparer<Pracownik>
            {
                public int Compare(Pracownik x, Pracownik y)
                {
                    return x.Zawod.CompareTo(y.Zawod);
                }
            }

            public class PoImieniu : IComparer<Pracownik>
            {
                public int Compare(Pracownik x, Pracownik y)

                {
                    return x.Imie.CompareTo(y.Imie);
                }
            }

        }
        public void Sortuj(IComparer<Pracownik> ic)
        {
            lista.Sort(ic);
        }
        
       public void ZapisConsole()
        {
            //int max = lista.FindLastIndex(); 
            for (int i = 0; i < lista.Count ; i++)
            {
                Console.WriteLine(lista[i].ToString());
            }

            /*
            foreach(Pracownik p in lista)
            {
                Console.WriteLine(p);
            }
            */

        }
        void OdczytConsole()
        {
            OdczytConsole();
        }

        public void Wyczysc()
        {
            lista.Clear();
        }
        public Pracownik this[int i]
        {
            get { return lista[i];  }
        }
        public int Rozmiar
        {
            get { return lista.Count;  }
        }

    }
}
