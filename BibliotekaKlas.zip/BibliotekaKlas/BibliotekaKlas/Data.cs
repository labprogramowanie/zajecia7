﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotekaKlas
{
    public class Data
    {
        private int dzien;
        private string miesiac;
        private int rok;
        private static readonly string[] miesiace = { "Styczen", "Luty", "Marzec", "Kwiecien", "Maj", "Czerwiec", "Lipiec", "Sierpien", "Wrzesien", "Pazdziernik", "Listopad", "Grudzien" };



        public int Dzien
            {
                get {return dzien; }
                set {dzien = value; }
            
            }
        
        public string Miesiac
            {
            get {return miesiac; }
            set { miesiac = value; }
            }
        public int Rok
            {
                get { return rok; }
                set { rok = value; }
            }

        public object Ulica { get; internal set; }

        public Data()
        {
            //konstruktor bezargumentowy
        }

        public Data(int d, string m, int r)
        {
            dzien = d;
            miesiac = m;
            rok = r;
            //this.rok = rok; - gdy argumenty pokrywaja sie z zawartoscia konstruktora
        }
        public Data (Data wzor)
        {
            dzien = wzor.dzien;
            miesiac = wzor.miesiac;
            rok = wzor.rok;
            // konstruktor kopiujacy
        }

        public override string ToString()
        {
            return dzien.ToString() + miesiac.ToString() + rok.ToString();
        }
        
        static string ZwrocMiesiac(int miesiac)
        {
            if (miesiac>=1 && miesiac<=12)
            {
                return miesiace[miesiac - 1];
            }
            else
            {
                return "Zly miesiac";
            }
        }


    }
}
